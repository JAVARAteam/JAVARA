package Workable;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.border.LineBorder;
import javax.swing.JTextArea;
import java.awt.Font;
import java.awt.Component;
import javax.swing.JTextPane;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.DropMode;
import javax.swing.JSplitPane;
import javax.swing.JLabel;
import java.awt.ComponentOrientation;
import java.awt.Container;
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.ImageIcon;

import javax.swing.JSeparator;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JSlider;
import javax.swing.SpringLayout;
import java.awt.event.KeyEvent;

public class javaraUI extends JFrame {

	private JPanel mainPanel;
	private JTextField mainText4;
	private JTextField mainText5;
	private JTextField mainText6;
	private JTextField mainText7;
	private JTextField mainText1;
	private JTextField mainText2;
	private JTextField mainText3;
	private JTextField maintext4;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					javaraUI frame = new javaraUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public javaraUI() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 560, 900);
		mainPanel = new JPanel();
		mainPanel.setForeground(Color.BLACK);
		mainPanel.setBackground(Color.WHITE);
		mainPanel.setBorder(new LineBorder(new Color(0, 0, 0)));

		setContentPane(mainPanel);
		mainPanel.setLayout(null);
		
		JPanel contentPanel = new JPanel();
		contentPanel.setBackground(Color.WHITE);
		contentPanel.setBorder(new LineBorder(new Color(255, 165, 0)));
		contentPanel.setBounds(0, 160, 544, 710);
		mainPanel.add(contentPanel);
		contentPanel.setLayout(null);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(0, 355, 560, 10);
		contentPanel.add(separator);
		
		JLabel trainingLabel = new JLabel("교육/훈련");
		trainingLabel.setFont(new Font("NanumSquare", Font.PLAIN, 30));
		trainingLabel.setBounds(10, 20, 534, 30);
		contentPanel.add(trainingLabel);
		
		JLabel mapLabel = new JLabel("지역별");
		mapLabel.setFont(new Font("NanumSquare", Font.PLAIN, 30));
		mapLabel.setBounds(10, 375, 544, 30);
		contentPanel.add(mapLabel);
		
		mainText4 = new JTextField();
		mainText4.setText("정보1");
		mainText4.setColumns(10);
		mainText4.setBorder(new LineBorder(new Color(0, 0, 0)));
		mainText4.setBounds(120, 62, 130, 130);
		contentPanel.add(mainText4);
		
		mainText5 = new JTextField();
		mainText5.setText("정보2");
		mainText5.setColumns(10);
		mainText5.setBorder(new LineBorder(new Color(0, 0, 0)));
		mainText5.setBounds(280, 62, 130, 130);
		contentPanel.add(mainText5);
		
		mainText6 = new JTextField();
		mainText6.setText("정보3");
		mainText6.setColumns(10);
		mainText6.setBorder(new LineBorder(new Color(0, 0, 0)));
		mainText6.setBounds(120, 204, 130, 130);
		contentPanel.add(mainText6);
		
		mainText7 = new JTextField();
		mainText7.setText("정보4");
		mainText7.setColumns(10);
		mainText7.setBorder(new LineBorder(new Color(0, 0, 0)));
		mainText7.setBounds(280, 204, 130, 130);
		contentPanel.add(mainText7);
		
		
		JLabel cityLabel = new JLabel("청주시");
		cityLabel.setDisplayedMnemonic(KeyEvent.VK_ENTER);
		cityLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		cityLabel.setFont(new Font("NanumSquare", Font.PLAIN, 20));
		cityLabel.setBounds(451, 355, 83, 46);
		contentPanel.add(cityLabel);
		
		ImageIcon icon7 = new ImageIcon("C:\\Users\\SAMSUNG\\eclipse-workspace\\Workable\\src\\image\\prevBtn.png");
		Image previm3 = icon7.getImage();
		Image previm4 = previm3.getScaledInstance(50, 50, Image.SCALE_DEFAULT);
		ImageIcon icon8 = new ImageIcon(previm4);
		JButton prevBtn = new JButton(icon8);
		prevBtn.setForeground(Color.ORANGE);
		prevBtn.setBorder(null);
		prevBtn.setBackground(Color.WHITE);
		prevBtn.setBounds(47, 175, 50, 50);
		contentPanel.add(prevBtn);
		
		ImageIcon icon5 = new ImageIcon("C:\\Users\\SAMSUNG\\eclipse-workspace\\Workable\\src\\image\\nextBtn.png");
		Image nextim3 = icon5.getImage();
		Image nextim4 = nextim3.getScaledInstance(50, 50, Image.SCALE_DEFAULT);
		ImageIcon icon6 = new ImageIcon(nextim4);
		JButton nextBtn = new JButton(icon6);
		nextBtn.setForeground(new Color(255, 200, 0));
		nextBtn.setBorder(null);
		nextBtn.setBackground(Color.WHITE);
		nextBtn.setBounds(433, 175, 50, 50);
		contentPanel.add(nextBtn);
		
		mainText1 = new JTextField();
		mainText1.setText("정보1");
		mainText1.setColumns(10);
		mainText1.setBorder(new LineBorder(new Color(0, 0, 0)));
		mainText1.setBounds(120, 417, 130, 130);
		contentPanel.add(mainText1);
		
		mainText2 = new JTextField();
		mainText2.setText("정보2");
		mainText2.setColumns(10);
		mainText2.setBorder(new LineBorder(new Color(0, 0, 0)));
		mainText2.setBounds(280, 417, 130, 130);
		contentPanel.add(mainText2);
		
		mainText3 = new JTextField();
		mainText3.setText("정보3");
		mainText3.setColumns(10);
		mainText3.setBorder(new LineBorder(new Color(0, 0, 0)));
		mainText3.setBounds(120, 559, 130, 130);
		contentPanel.add(mainText3);
		
		maintext4 = new JTextField();
		maintext4.setText("정보4");
		maintext4.setColumns(10);
		maintext4.setBorder(new LineBorder(new Color(0, 0, 0)));
		maintext4.setBounds(280, 559, 130, 130);
		contentPanel.add(maintext4);
		
		ImageIcon icon = new ImageIcon("C:\\Users\\SAMSUNG\\eclipse-workspace\\Workable\\src\\image\\prevBtn.png");
		Image previm = icon.getImage();
		Image previm2 = previm.getScaledInstance(50, 50, Image.SCALE_DEFAULT);
		ImageIcon icon2 = new ImageIcon(previm2);
		JButton prevBtn_1 = new JButton(icon2);
		prevBtn_1.setForeground(Color.ORANGE);
		prevBtn_1.setBorder(null);
		prevBtn_1.setBackground(Color.WHITE);
		prevBtn_1.setBounds(47, 530, 50, 50);
		contentPanel.add(prevBtn_1);
		
		
		ImageIcon icon3 = new ImageIcon("C:\\Users\\SAMSUNG\\eclipse-workspace\\Workable\\src\\image\\nextBtn.png");
		Image nextim = icon3.getImage();
		Image nextim2 = nextim.getScaledInstance(50, 50, Image.SCALE_DEFAULT);
		ImageIcon icon4 = new ImageIcon(nextim2);
		JButton nextBtn_1 = new JButton(icon4);
		nextBtn_1.setForeground(Color.ORANGE);
		nextBtn_1.setBorder(null);
		nextBtn_1.setBackground(Color.WHITE);
		nextBtn_1.setBounds(433, 530, 50, 50);
		contentPanel.add(nextBtn_1);
		
		JPanel topPanel = new JPanel();
		topPanel.setBorder(new LineBorder(new Color(255, 165, 0)));
		topPanel.setName("Workable");
		topPanel.setFont(new Font("NanumSquare", Font.PLAIN, 15));
		topPanel.setToolTipText("Workable");
		topPanel.setBackground(new Color(255, 165, 0));
		topPanel.setBounds(0, 0, 544, 80);
		mainPanel.add(topPanel);
		topPanel.setLayout(null);
		
		ImageIcon icon9 = new ImageIcon("C:\\Users\\SAMSUNG\\eclipse-workspace\\Workable\\src\\image\\logo.png");
		Image logoImg = icon9.getImage();
		logoImg = logoImg.getScaledInstance(200, 100, Image.SCALE_DEFAULT);
		ImageIcon logoIcon = new ImageIcon(logoImg);
		JLabel topLabel = new JLabel(logoIcon);
		topLabel.setBounds(239, 32, 57, 15);
		topPanel.add(topLabel);
		topLabel.setBackground(new Color(255, 165, 0));
		topLabel.setBounds(0, -5, 544, 80);
		topLabel.setAlignmentX(0.5f);
		topLabel.setHorizontalAlignment(SwingConstants.CENTER);
		topLabel.setFont(new Font("NanumSquare", Font.PLAIN, 40));
		
		JPanel subPanel = new JPanel();
		subPanel.setBounds(0, 80, 544, 80);
		mainPanel.add(subPanel);
		subPanel.setBackground(Color.WHITE);
		subPanel.setBorder(new LineBorder(new Color(255, 165, 0)));
		subPanel.setLayout(null);
		
		JButton regionBtn = new JButton("지역");
		regionBtn.setFocusable(false);
		regionBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				regionUI region = new regionUI();
				region.setVisible(true);
				setVisible(false);
			}
		});
		regionBtn.setBorder(null);
		regionBtn.setFont(new Font("NanumSquare", Font.PLAIN, 30));
		regionBtn.setBackground(Color.WHITE);
		regionBtn.setBounds(56, 25, 70, 30);
		subPanel.add(regionBtn);
		
		JButton mapBtn = new JButton("지도");
		mapBtn.setFocusable(false);
		mapBtn.setFont(new Font("NanumSquare", Font.PLAIN, 30));
		mapBtn.setBorder(null);
		mapBtn.setBackground(Color.WHITE);
		mapBtn.setBounds(182, 25, 70, 30);
		subPanel.add(mapBtn);
		mapBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				mapSearchUI mapSearch = new mapSearchUI();
				mapSearch.setVisible(true);
				setVisible(false);
			}
		});
		
		JButton jobBtn = new JButton("직무");
		jobBtn.setFocusable(false);
		jobBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				jobUI job = new jobUI();
				job.setVisible(true);
				setVisible(false);
			}
			
		});
		jobBtn.setFont(new Font("NanumSquare", Font.PLAIN, 30));
		jobBtn.setBorder(null);
		jobBtn.setBackground(Color.WHITE);
		jobBtn.setBounds(308, 25, 70, 30);
		subPanel.add(jobBtn);
		
		JButton trainingBtn = new JButton("교육");
		trainingBtn.setFocusable(false);
		trainingBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				trainingUI training = new trainingUI();
				training.setVisible(true);
				setVisible(false);
			}
		});
		trainingBtn.setFont(new Font("NanumSquare", Font.PLAIN, 30));
		trainingBtn.setBorder(null);
		trainingBtn.setBackground(Color.WHITE);
		trainingBtn.setBounds(434, 25, 70, 30);
		subPanel.add(trainingBtn);
		
		
		
	}
}
