package Workable;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

public class recruitmentInformationUI extends JFrame {

	private JPanel recruitShow;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					recruitmentInformationUI frame = new recruitmentInformationUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public recruitmentInformationUI() {
		setVisible(true);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 560, 900);
		recruitShow = new JPanel();
		recruitShow.setForeground(Color.BLACK);
		recruitShow.setBackground(Color.WHITE);
		recruitShow.setBorder(new LineBorder(new Color(0, 0, 0)));

		setContentPane(recruitShow);
		recruitShow.setLayout(null);
		
		JPanel subPanel = new JPanel();
		subPanel.setForeground(new Color(0, 0, 0));
		subPanel.setBorder(new LineBorder(new Color(0, 0, 0)));
		subPanel.setBackground(Color.white);
		subPanel.setBounds(12, 111, 205, 177);
		recruitShow.add(subPanel);
		
		JPanel subPanel1 = new JPanel();
		subPanel1.setBackground(new Color(255, 255, 255));
		subPanel1.setForeground(new Color(0, 0, 0));
		subPanel1.setBorder(new LineBorder(Color.BLACK));
		subPanel1.setBackground(Color.white);
		subPanel1.setFont(new Font("나눔스퀘어", Font.PLAIN, 16));
		subPanel1.setBounds(12, 311, 520, 509);
		recruitShow.add(subPanel1);
		
		JLabel subLabel1 = new JLabel("<html><body><center>이 곳에 기업 정보,<br> <br>기업 설명 등 채용정보가 나옵니다.</center></body></html>");
		subLabel1.setBackground(Color.WHITE);
		subLabel1.setBounds(0, 37, 264, 34);
		subLabel1.setAlignmentX(0.5f);
		subLabel1.setHorizontalAlignment(SwingConstants.CENTER);
		subLabel1.setFont(new Font("나눔스퀘어", Font.PLAIN, 16));
		subPanel1.add(subLabel1);
		
		JPanel topPanel = new JPanel();
		topPanel.setBorder(new LineBorder(Color.black));
		topPanel.setName("Workable");
		topPanel.setFont(new Font("NanumSquare", Font.PLAIN, 15));
		topPanel.setToolTipText("Workable");
		topPanel.setBackground(new Color(255, 165, 0));
		topPanel.setBounds(0, 0, 544, 80);
		recruitShow.add(topPanel);
		topPanel.setLayout(null);
		
		ImageIcon icon = new ImageIcon("C:\\Users\\SAMSUNG\\eclipse-workspace\\Workable\\src\\image\\backBtn.png");
		Image backim = icon.getImage();
		Image backim2 = backim.getScaledInstance(30, 30, Image.SCALE_DEFAULT);
		ImageIcon icon2 = new ImageIcon(backim2);
		JButton backBtn = new JButton(icon2);
		backBtn.setBackground(new Color(255, 165, 0));
		backBtn.setBorder(null);
		backBtn.setBounds(12, 16, 48, 48);
		topPanel.add(backBtn);
		
		ImageIcon icon9 = new ImageIcon("C:\\Users\\SAMSUNG\\eclipse-workspace\\Workable\\src\\image\\logo.png");
		Image logoImg = icon9.getImage();
		logoImg = logoImg.getScaledInstance(200, 100, Image.SCALE_DEFAULT);
		ImageIcon logoIcon = new ImageIcon(logoImg);
		JLabel topLabel = new JLabel(logoIcon);
		topLabel.setBounds(239, 32, 57, 15);
		topPanel.add(topLabel);
		topLabel.setBackground(new Color(255, 165, 0));
		topLabel.setBounds(0, -5, 544, 80);
		topLabel.setAlignmentX(0.5f);
		topLabel.setHorizontalAlignment(SwingConstants.CENTER);
		topLabel.setFont(new Font("NanumSquare", Font.PLAIN, 40));

		backBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				javaraUI javaraUI = new javaraUI();
				javaraUI.setVisible(true);
				setVisible(false);
			}
		});
		
		JButton preButton = new JButton("이전");
		preButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		preButton.setBounds(156, 828, 97, 23);
		recruitShow.add(preButton);
		
		JButton nextButton = new JButton("다음");
		nextButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		nextButton.setBounds(278, 828, 97, 23);
		recruitShow.add(nextButton);
		
		JPanel subPanel4 = new JPanel();
		subPanel4.setBorder(null);
		subPanel4.setBackground(new Color(255, 255, 255));
		subPanel4.setBounds(229, 111, 303, 177);
		recruitShow.add(subPanel4);
		
		JLabel subLabel = new JLabel("<html><body><center>이 곳에 간략한<br> <br>채용정보가 나옵니다.</center></body></html>");
		subLabel.setBackground(Color.WHITE);
		subLabel.setBounds(0, 37, 264, 34);
		subLabel.setAlignmentX(0.5f);
		subLabel.setHorizontalAlignment(SwingConstants.CENTER);
		subLabel.setFont(new Font("나눔스퀘어", Font.PLAIN, 16));
		subPanel4.add(subLabel);
	
		
	}
}
