package Workable;

import java.awt.Color;
import java.awt.Container;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class mapSearchUI extends JFrame{
	
	private JPanel mapShow;
	private JTextField recruitInformation1;
	private JTextField recruitInformation2;
	private JTextField recruitInformation3;
	private JTextField recruitInformation4;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					mapSearchUI frame = new mapSearchUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public mapSearchUI() {
		setVisible(true);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 560, 900);
		mapShow = new JPanel();
		mapShow.setForeground(Color.BLACK);
		mapShow.setBackground(Color.WHITE);
		mapShow.setBorder(new LineBorder(new Color(0, 0, 0)));

		setContentPane(mapShow);
		mapShow.setLayout(null);
		
		JPanel mapSquare = new JPanel();
		mapSquare.setFocusable(false);
		mapSquare.setBounds(0, 80, 544, 310);
		mapSquare.setBackground(Color.WHITE);
		mapSquare.setBorder(new LineBorder(new Color(255, 165, 0)));
		mapSquare.setBorder(null);
		mapShow.add(mapSquare);
		mapSquare.setLayout(null);
		
		JPanel recruitShow = new JPanel();
		recruitShow.setBackground(Color.WHITE);
		recruitShow.setBorder(new LineBorder(new Color(0, 0, 0)));
		recruitShow.setBounds(0, 390, 544, 471);
		mapShow.add(recruitShow);
		recruitShow.setLayout(null);
		
		recruitInformation1 = new JTextField();
		recruitInformation1.setFont(new Font("나눔스퀘어", Font.PLAIN, 16));
		recruitInformation1.setBounds(0, 0, 544, 100);
		recruitInformation1.setText("채용 정보 1");
		recruitInformation1.setColumns(10);
		recruitInformation1.setBorder(new LineBorder(new Color(0, 0, 0)));
		recruitShow.add(recruitInformation1);
		
		recruitInformation2 = new JTextField();
		recruitInformation2.setFont(new Font("나눔스퀘어", Font.PLAIN, 16));
		recruitInformation2.setText("채용 정보 2");
		recruitInformation2.setColumns(10);
		recruitInformation2.setBorder(new LineBorder(new Color(0, 0, 0)));
		recruitInformation2.setBounds(0, 100, 544, 100);
		recruitShow.add(recruitInformation2);
		
		recruitInformation3 = new JTextField();
		recruitInformation3.setFont(new Font("나눔스퀘어", Font.PLAIN, 16));
		recruitInformation3.setText("채용 정보 3");
		recruitInformation3.setColumns(10);
		recruitInformation3.setBorder(new LineBorder(new Color(0, 0, 0)));
		recruitInformation3.setBounds(0, 200, 544, 100);
		recruitShow.add(recruitInformation3);
		
		recruitInformation4 = new JTextField();
		recruitInformation4.setFont(new Font("나눔스퀘어", Font.PLAIN, 16));
		recruitInformation4.setText("채용 정보 4");
		recruitInformation4.setColumns(10);
		recruitInformation4.setBorder(new LineBorder(new Color(0, 0, 0)));
		recruitInformation4.setBounds(0, 300, 544, 100);
		recruitShow.add(recruitInformation4);
		
		JPanel topPanel = new JPanel();
		topPanel.setBorder(new LineBorder(new Color(0, 0, 0)));
		topPanel.setName("취업 지도");
		topPanel.setFont(new Font("NanumSquare", Font.PLAIN, 40));
		topPanel.setToolTipText("취업 지도");
		topPanel.setBackground(new Color(255, 165, 0));
		topPanel.setBorder(new LineBorder(new Color(255, 165, 0)));
		topPanel.setBounds(0, 0, 544, 80);
		mapShow.add(topPanel);
		topPanel.setLayout(null);
		
		ImageIcon icon = new ImageIcon("C:\\Users\\SAMSUNG\\eclipse-workspace\\Workable\\src\\image\\prevBtn.png");
		Image previm = icon.getImage();
		Image previm2 = previm.getScaledInstance(40, 40, Image.SCALE_DEFAULT);
		ImageIcon icon2 = new ImageIcon(previm2);
		JButton prevBtn = new JButton(icon2);
		prevBtn.setForeground(Color.ORANGE);
		prevBtn.setBorder(null);
		prevBtn.setBackground(Color.WHITE);
		prevBtn.setBounds(184, 421, 43, 40);
		recruitShow.add(prevBtn);
		
		
		ImageIcon icon3 = new ImageIcon("C:\\Users\\SAMSUNG\\eclipse-workspace\\Workable\\src\\image\\nextBtn.png");
		Image nextim = icon3.getImage();
		Image nextim2 = nextim.getScaledInstance(40, 40, Image.SCALE_DEFAULT);
		ImageIcon icon4 = new ImageIcon(nextim2);
		JButton nextBtn = new JButton(icon4);
		nextBtn.setForeground(Color.ORANGE);
		nextBtn.setBorder(null);
		nextBtn.setBackground(Color.WHITE);
		nextBtn.setBounds(294, 421, 43, 40);
		recruitShow.add(nextBtn);
		
		ImageIcon icon5 = new ImageIcon("C:\\Users\\SAMSUNG\\eclipse-workspace\\Workable\\src\\image\\backBtn.png");
		Image backim = icon5.getImage();
		Image backim2 = backim.getScaledInstance(30, 30, Image.SCALE_DEFAULT);
		ImageIcon icon6 = new ImageIcon(backim2);
		JButton backBtn = new JButton(icon6);
		backBtn.setFocusable(false);
		backBtn.setBorder(null);
		backBtn.setBackground(new Color(255, 165, 0));
		backBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				javaraUI javara = new javaraUI();
				javara.setVisible(true);
				setVisible(false);
			}
		});
		backBtn.setBounds(12, 16, 48, 48);
		topPanel.add(backBtn);
		
		
		JLabel mainLabel = new JLabel("취업 지도");
		mainLabel.setForeground(new Color(0, 0, 0));
		mainLabel.setBackground(Color.ORANGE);
		mainLabel.setBounds(0, 20, 544, 48);
		mainLabel.setAlignmentX(0.5f);
		mainLabel.setHorizontalAlignment(SwingConstants.CENTER);
		mainLabel.setFont(new Font("나눔스퀘어", Font.PLAIN, 40));
		topPanel.add(mainLabel);
		
	}
	
}
