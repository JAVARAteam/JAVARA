package Workable;

public class DBlink {
	   public static void main(String[] args) {
	      //EmploymentDB emdb = new EmploymentDB();
		  WelfareDB wldb = new WelfareDB();
	      ed_info ed = new ed_info();
	      //emdb.selectOne();
	      //wldb.selectOne();
	      ed.selectOne();
	   }
	}
