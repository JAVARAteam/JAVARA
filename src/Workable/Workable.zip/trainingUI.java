package Workable;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.BevelBorder;
import javax.swing.UIManager;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class trainingUI extends JFrame {

	private JPanel mainPanel;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					trainingUI frame = new trainingUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public trainingUI() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 560, 900);
		mainPanel = new JPanel();
		mainPanel.setForeground(Color.BLACK);
		mainPanel.setBackground(Color.WHITE);
		mainPanel.setBorder(new LineBorder(new Color(0, 0, 0)));

		setContentPane(mainPanel);
		mainPanel.setLayout(null);
		
		JPanel contentPanel = new JPanel();
		contentPanel.setBackground(Color.WHITE);
		contentPanel.setBorder(new LineBorder(new Color(255, 165, 0)));
		contentPanel.setBounds(0, 80, 544, 790);
		mainPanel.add(contentPanel);
		contentPanel.setLayout(null);
		
		JSeparator separator1 = new JSeparator();
		separator1.setBounds(0, 100, 560, 10);
		contentPanel.add(separator1);
		
		JSeparator separator2 = new JSeparator();
		separator2.setBounds(0, 200, 560, 10);
		contentPanel.add(separator2);
		
		JSeparator separator3 = new JSeparator();
		separator3.setBounds(0, 300, 560, 10);
		contentPanel.add(separator3);
		
		JSeparator separator4 = new JSeparator();
		separator4.setBounds(0, 400, 560, 10);
		contentPanel.add(separator4);
		
		JSeparator separator5 = new JSeparator();
		separator5.setBounds(0, 500, 560, 10);
		contentPanel.add(separator5);
		
		JSeparator separator6 = new JSeparator();
		separator6.setBounds(0, 600, 560, 10);
		contentPanel.add(separator6);
		
		JSeparator separator7 = new JSeparator();
		separator7.setBounds(0, 700, 560, 10);
		contentPanel.add(separator7);
		
		JTextField trainingLabel = new JTextField();
		trainingLabel.setBorder(null);
		trainingLabel.setFont(new Font("NanumSquare", Font.PLAIN, 30));
		trainingLabel.setHorizontalAlignment(SwingConstants.CENTER);
		trainingLabel.setText("장애인 직업 능력 개발훈련");
		trainingLabel.setBounds(10, 35, 534, 30);
		contentPanel.add(trainingLabel);
		trainingLabel.setColumns(10);
		
		JTextField mainText1 = new JTextField();
		mainText1.setBorder(null);
		mainText1.setBackground(Color.WHITE);
		mainText1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				recruitmentInformationUI recruitmentInfo1 = new recruitmentInformationUI();
				recruitmentInfo1.setVisible(true);
				setVisible(false);
			}
		});
		mainText1.setEditable(false);
		mainText1.setText("내용");
		mainText1.setColumns(10);
		mainText1.setBounds(142, 138, 252, 26);
		contentPanel.add(mainText1);
		
		JTextField mainText2 = new JTextField();
		mainText2.setBorder(null);
		mainText2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				recruitmentInformationUI recruitmentInfo1 = new recruitmentInformationUI();
				recruitmentInfo1.setVisible(true);
				setVisible(false);
			}
		});
		mainText2.setText("내용");
		mainText2.setColumns(10);
		mainText2.setBounds(142, 238, 252, 26);
		contentPanel.add(mainText2);
		
		JTextField mainText3 = new JTextField();
		mainText3.setBorder(null);
		mainText3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				recruitmentInformationUI recruitmentInfo1 = new recruitmentInformationUI();
				recruitmentInfo1.setVisible(true);
				setVisible(false);
			}
		});
		mainText3.setText("내용");
		mainText3.setBounds(142, 338, 252, 26);
		contentPanel.add(mainText3);
		mainText3.setColumns(10);
		
		JTextField mainText4 = new JTextField();
		mainText4.setBorder(null);
		mainText4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				recruitmentInformationUI recruitmentInfo1 = new recruitmentInformationUI();
				recruitmentInfo1.setVisible(true);
				setVisible(false);
			}
		});
		mainText4.setText("내용");
		mainText4.setColumns(10);
		mainText4.setBounds(142, 438, 252, 26);
		contentPanel.add(mainText4);
		
		JTextField mainText5 = new JTextField();
		mainText5.setBorder(null);
		mainText5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				recruitmentInformationUI recruitmentInfo1 = new recruitmentInformationUI();
				recruitmentInfo1.setVisible(true);
				setVisible(false);
			}
		});
		mainText5.setText("내용");
		mainText5.setColumns(10);
		mainText5.setBounds(142, 538, 252, 26);
		contentPanel.add(mainText5);
		
		JTextField mainText6 = new JTextField();
		mainText6.setBorder(null);
		mainText6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				recruitmentInformationUI recruitmentInfo1 = new recruitmentInformationUI();
				recruitmentInfo1.setVisible(true);
				setVisible(false);
			}
		});
		mainText6.setText("내용");
		mainText6.setColumns(10);
		mainText6.setBounds(142, 638, 252, 26);
		contentPanel.add(mainText6);
		
		ImageIcon icon = new ImageIcon("C:\\Users\\SAMSUNG\\eclipse-workspace\\Workable\\src\\image\\prevBtn.png");
		Image previm = icon.getImage();
		Image previm2 = previm.getScaledInstance(50, 50, Image.SCALE_DEFAULT);
		ImageIcon icon2 = new ImageIcon(previm2);
		JButton prevBtn = new JButton(icon2);
		prevBtn.setForeground(Color.ORANGE);
		prevBtn.setBorder(null);
		prevBtn.setBackground(Color.WHITE);
		prevBtn.setBounds(184, 722, 50, 50);
		contentPanel.add(prevBtn);
		
		ImageIcon icon3 = new ImageIcon("C:\\Users\\SAMSUNG\\eclipse-workspace\\Workable\\src\\image\\nextBtn.png");
		Image nextim3 = icon3.getImage();
		Image nextim4 = nextim3.getScaledInstance(50, 50, Image.SCALE_DEFAULT);
		ImageIcon icon4 = new ImageIcon(nextim4);
		JButton nextBtn = new JButton(icon4);
		nextBtn.setForeground(Color.ORANGE);
		nextBtn.setBorder(null);
		nextBtn.setBackground(Color.WHITE);		
		nextBtn.setBounds(294, 722, 50, 50);
		contentPanel.add(nextBtn);
		
		JPanel topPanel = new JPanel();
		topPanel.setBorder(new LineBorder(new Color(0, 0, 0)));
		topPanel.setName("Workable");
		topPanel.setFont(new Font("NanumSquare", Font.PLAIN, 15));
		topPanel.setToolTipText("Workable");
		topPanel.setBackground(new Color(255, 165, 0));
		topPanel.setBorder(new LineBorder(new Color(255, 165, 0)));
		topPanel.setBounds(0, 0, 560, 80);
		mainPanel.add(topPanel);
		topPanel.setLayout(null);
		
		JLabel topLabel = new JLabel("교육/훈련");
		topLabel.setBounds(0, 20, 560, 40);
		topLabel.setAlignmentX(0.5f);
		topLabel.setHorizontalAlignment(SwingConstants.CENTER);
		topLabel.setFont(new Font("NanumSquare", Font.PLAIN, 40));
		topPanel.add(topLabel);
		
		ImageIcon icon5 = new ImageIcon("C:\\Users\\SAMSUNG\\eclipse-workspace\\Workable\\src\\image\\backBtn.png");
		Image backim = icon5.getImage();
		Image backim2 = backim.getScaledInstance(30, 30, Image.SCALE_DEFAULT);
		ImageIcon icon6 = new ImageIcon(backim2);
		JButton backBtn = new JButton(icon6);
		backBtn.setFocusable(false);
		backBtn.setBorder(null);
		backBtn.setBackground(new Color(255, 165, 0));
		backBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				javaraUI javara = new javaraUI();
				javara.setVisible(true);
				setVisible(false);
			}
		});
		backBtn.setBounds(12, 16, 48, 48);
		topPanel.add(backBtn);
	}
}
