package Workable;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionEvent;

public class jobUI extends JFrame {

	private JPanel mainPanel;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					jobUI frame = new jobUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public jobUI() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 560, 900);
		mainPanel = new JPanel();
		mainPanel.setForeground(Color.BLACK);
		mainPanel.setBackground(Color.WHITE);
		mainPanel.setBorder(new LineBorder(new Color(0, 0, 0)));

		setContentPane(mainPanel);
		mainPanel.setLayout(null);
		
		JPanel contentPanel = new JPanel();
		contentPanel.setBackground(Color.WHITE);
		contentPanel.setBorder(new LineBorder(new Color(255, 165, 0)));
		contentPanel.setBounds(0, 80, 544, 790);
		mainPanel.add(contentPanel);
		contentPanel.setLayout(null);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(0, 300, 560, 10);
		contentPanel.add(separator);
		
		JSeparator separator2 = new JSeparator();
		separator2.setBounds(0, 400, 560, 10);
		contentPanel.add(separator2);
		
		JSeparator separator3 = new JSeparator();
		separator3.setBounds(0, 500, 560, 10);
		contentPanel.add(separator3);
		
		JSeparator separator4 = new JSeparator();
		separator4.setBounds(0, 600, 560, 10);
		contentPanel.add(separator4);
		
		JSeparator separator5 = new JSeparator();
		separator5.setBounds(0, 700, 560, 10);
		contentPanel.add(separator5);
		
		JPanel jobPanel = new JPanel();
		jobPanel.setBorder(new LineBorder(new Color(0, 0, 0)));
		jobPanel.setBackground(Color.WHITE);
		jobPanel.setBounds(16, 59, 510, 170);
		contentPanel.add(jobPanel);
		jobPanel.setLayout(null);
		
		JTextField mainText1 = new JTextField();
		mainText1.setBorder(null);
		mainText1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				recruitmentInformationUI recruitmentInfo1 = new recruitmentInformationUI();
				recruitmentInfo1.setVisible(true);
				setVisible(false);
			}
		});
		mainText1.setText("내용");
		mainText1.setBounds(142, 339, 252, 26);
		contentPanel.add(mainText1);
		mainText1.setColumns(10);
		
		JTextField mainText2 = new JTextField();
		mainText2.setBorder(null);
		mainText2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				recruitmentInformationUI recruitmentInfo1 = new recruitmentInformationUI();
				recruitmentInfo1.setVisible(true);
				setVisible(false);
			}
		});
		mainText2.setText("내용");
		mainText2.setColumns(10);
		mainText2.setBounds(142, 438, 252, 26);
		contentPanel.add(mainText2);
		
		JTextField mainText3 = new JTextField();
		mainText3.setBorder(null);
		mainText3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				recruitmentInformationUI recruitmentInfo1 = new recruitmentInformationUI();
				recruitmentInfo1.setVisible(true);
				setVisible(false);
			}
		});
		mainText3.setText("내용");
		mainText3.setColumns(10);
		mainText3.setBounds(142, 538, 252, 26);
		contentPanel.add(mainText3);
		
		JTextField mainText4 = new JTextField();
		mainText4.setBorder(null);
		mainText4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				recruitmentInformationUI recruitmentInfo1 = new recruitmentInformationUI();
				recruitmentInfo1.setVisible(true);
				setVisible(false);
			}
		});
		mainText4.setText("내용");
		mainText4.setColumns(10);
		mainText4.setBounds(142, 638, 252, 26);
		contentPanel.add(mainText4);
		
		ImageIcon originalIcon = new ImageIcon("C:\\Users\\SAMSUNG\\eclipse-workspace\\Workable\\src\\image\\filter.png");
		Image filterImg = originalIcon.getImage();
		filterImg = filterImg.getScaledInstance(130, 50, Image.SCALE_DEFAULT);
		ImageIcon filterIcon = new ImageIcon(filterImg);
		JLabel advancedSearchBtn = new JLabel(filterIcon);
		advancedSearchBtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				advancedSearchUI advancedSearch = new advancedSearchUI();
				advancedSearch.setVisible(true);
				setVisible(false);
			}
		});
		
		advancedSearchBtn.setBounds(383, 241, 152, 51);
		contentPanel.add(advancedSearchBtn);
		
		ImageIcon icon = new ImageIcon("C:\\Users\\SAMSUNG\\eclipse-workspace\\Workable\\src\\image\\prevBtn.png");
		Image previm = icon.getImage();
		Image previm2 = previm.getScaledInstance(50, 50, Image.SCALE_DEFAULT);
		ImageIcon icon2 = new ImageIcon(previm2);
		JButton prevBtn = new JButton(icon2);
		prevBtn.setForeground(Color.ORANGE);
		prevBtn.setBorder(null);
		prevBtn.setBackground(Color.WHITE);
		prevBtn.setBounds(184, 722, 50, 50);
		contentPanel.add(prevBtn);
		
		ImageIcon icon3 = new ImageIcon("C:\\Users\\SAMSUNG\\eclipse-workspace\\Workable\\src\\image\\nextBtn.png");
		Image nextim3 = icon3.getImage();
		Image nextim4 = nextim3.getScaledInstance(50, 50, Image.SCALE_DEFAULT);
		ImageIcon icon4 = new ImageIcon(nextim4);
		JButton nextBtn = new JButton(icon4);
		nextBtn.setForeground(Color.ORANGE);
		nextBtn.setBorder(null);
		nextBtn.setBackground(Color.WHITE);		
		nextBtn.setBounds(294, 722, 50, 50);
		contentPanel.add(nextBtn);
		
		JPanel topPanel = new JPanel();
		topPanel.setBorder(new LineBorder(new Color(0, 0, 0)));
		topPanel.setName("Workable");
		topPanel.setFont(new Font("NanumSquare", Font.PLAIN, 15));
		topPanel.setToolTipText("Workable");
		topPanel.setBackground(new Color(255, 165, 0));
		topPanel.setBounds(0, 0, 560, 80);
		topPanel.setBorder(new LineBorder(new Color(255, 165, 0)));
		mainPanel.add(topPanel);
		topPanel.setLayout(null);
		
		JLabel topLabel = new JLabel("직무별");
		topLabel.setBackground(new Color(240, 240, 240));
		topLabel.setBounds(0, 20, 544, 40);
		topLabel.setAlignmentX(0.5f);
		topLabel.setHorizontalAlignment(SwingConstants.CENTER);
		topLabel.setFont(new Font("NanumSquare", Font.PLAIN, 40));
		topPanel.add(topLabel);
	
		ImageIcon icon5 = new ImageIcon("C:\\Users\\SAMSUNG\\eclipse-workspace\\Workable\\src\\image\\backBtn.png");
		Image backim = icon5.getImage();
		Image backim2 = backim.getScaledInstance(30, 30, Image.SCALE_DEFAULT);
		ImageIcon icon6 = new ImageIcon(backim2);
		JButton backBtn = new JButton(icon6);
		backBtn.setFocusable(false);
		backBtn.setBorder(null);
		backBtn.setSize(48, 48);
		backBtn.setLocation(12, 18);
		backBtn.setBackground(new Color(255, 165, 0));
		topPanel.add(backBtn);
		backBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				javaraUI javaraUI = new javaraUI();
				javaraUI.setVisible(true);
				setVisible(false);
			}
		});
		topPanel.add(backBtn);
	}

}
