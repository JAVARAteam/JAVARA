package Workable;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class regionUI extends JFrame {

	private JPanel mainPanel;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					regionUI frame = new regionUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public regionUI() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 560, 900);
		mainPanel = new JPanel();
		mainPanel.setForeground(Color.BLACK);
		mainPanel.setBackground(Color.WHITE);
		mainPanel.setBorder(new LineBorder(new Color(0, 0, 0)));

		setContentPane(mainPanel);
		mainPanel.setLayout(null);
		
		JPanel contentPanel = new JPanel();
		contentPanel.setFocusable(false);
		contentPanel.setBackground(Color.WHITE);
		contentPanel.setBorder(new LineBorder(new Color(255, 165, 0)));
		contentPanel.setBounds(0, 80, 544, 792);
		mainPanel.add(contentPanel);
		contentPanel.setLayout(null);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(0, 300, 560, 10);
		contentPanel.add(separator);
		
		JSeparator separator2 = new JSeparator();
		separator2.setBounds(0, 400, 560, 10);
		contentPanel.add(separator2);
		
		JSeparator separator3 = new JSeparator();
		separator3.setBounds(0, 500, 560, 10);
		contentPanel.add(separator3);
		
		JSeparator separator4 = new JSeparator();
		separator4.setBounds(0, 600, 560, 10);
		contentPanel.add(separator4);
		
		JSeparator separator5 = new JSeparator();
		separator5.setBounds(0, 700, 560, 10);
		contentPanel.add(separator5);
		
		JTextField regionLabel = new JTextField();
		regionLabel.setBackground(Color.WHITE);
		regionLabel.setEditable(false);
		regionLabel.setBorder(null);
		regionLabel.setFont(new Font("NanumSquare", Font.PLAIN, 30));
		regionLabel.setHorizontalAlignment(SwingConstants.CENTER);
		regionLabel.setText("시/도");
		regionLabel.setBounds(12, 21, 520, 26);
		contentPanel.add(regionLabel);
		regionLabel.setColumns(10);
		
		JPanel regionPanel = new JPanel();
		regionPanel.setBorder(new LineBorder(new Color(255, 165, 0)));
		regionPanel.setBackground(Color.WHITE);
		regionPanel.setBounds(18, 59, 510, 170);
		contentPanel.add(regionPanel);
		regionPanel.setLayout(null);
		
		JButton seoulBtn = new JButton("서울");
		seoulBtn.setFocusable(false);
		seoulBtn.addMouseListener(new MouseAdapter() {
			boolean isChecked = false;
			@Override
			public void mouseClicked(MouseEvent e) {
				if(!isChecked) {
					seoulBtn.setFont(new Font("NanumSquare", Font.BOLD | Font.ITALIC, 30));
					isChecked = true;
				}
				else {
					seoulBtn.setFont(new Font("NanumSquare", Font.PLAIN, 30));
					isChecked = false;
				}
			}
		});
		seoulBtn.setBorder(null);
		seoulBtn.setBackground(Color.WHITE);
		seoulBtn.setHorizontalAlignment(SwingConstants.LEFT);
		seoulBtn.setFont(new Font("NanumSquare", Font.PLAIN, 30));
		seoulBtn.setBounds(15, 20, 60, 30);
		seoulBtn.setForeground(Color.BLACK);
		regionPanel.add(seoulBtn);
		
		JButton kyeonggiBtn = new JButton("경기");
		kyeonggiBtn.setFocusable(false);
		kyeonggiBtn.addMouseListener(new MouseAdapter() {
			boolean isChecked = false;
			@Override
			public void mouseClicked(MouseEvent e) {
				if(!isChecked) {
					kyeonggiBtn.setFont(new Font("NanumSquare", Font.BOLD | Font.ITALIC, 30));
					isChecked = true;
				}
				else {
					kyeonggiBtn.setFont(new Font("NanumSquare", Font.PLAIN, 30));
					isChecked = false;
				}
			}
		});
		kyeonggiBtn.setBorder(null);
		kyeonggiBtn.setBackground(Color.WHITE);
		kyeonggiBtn.setHorizontalAlignment(SwingConstants.LEFT);
		kyeonggiBtn.setForeground(Color.BLACK);
		kyeonggiBtn.setFont(new Font("NanumSquare", Font.PLAIN, 30));
		kyeonggiBtn.setBounds(99, 20, 60, 30);
		regionPanel.add(kyeonggiBtn);
		
		JButton incheonBtn = new JButton("인천");
		incheonBtn.setFocusable(false);
		incheonBtn.addMouseListener(new MouseAdapter() {
			boolean isChecked = false;
			@Override
			public void mouseClicked(MouseEvent e) {
				if(!isChecked) {
					incheonBtn.setFont(new Font("NanumSquare", Font.BOLD | Font.ITALIC, 30));
					isChecked = true;
				}
				else {
					incheonBtn.setFont(new Font("NanumSquare", Font.PLAIN, 30));
					isChecked = false;
				}
			}
		});
		incheonBtn.setBorder(null);
		incheonBtn.setBackground(Color.WHITE);
		incheonBtn.setHorizontalAlignment(SwingConstants.LEFT);
		incheonBtn.setForeground(Color.BLACK);
		incheonBtn.setFont(new Font("NanumSquare", Font.PLAIN, 30));
		incheonBtn.setBounds(183, 20, 60, 30);
		regionPanel.add(incheonBtn);
		
		JButton kangwonBtn = new JButton("강원");
		kangwonBtn.setFocusable(false);
		kangwonBtn.addMouseListener(new MouseAdapter() {
			boolean isChecked = false;
			@Override
			public void mouseClicked(MouseEvent e) {
				if(!isChecked) {
					kangwonBtn.setFont(new Font("NanumSquare", Font.BOLD | Font.ITALIC, 30));
					isChecked = true;
				}
				else {
					kangwonBtn.setFont(new Font("NanumSquare", Font.PLAIN, 30));
					isChecked = false;
				}
			}
		});
		kangwonBtn.setBorder(null);
		kangwonBtn.setBackground(Color.WHITE);
		kangwonBtn.setHorizontalAlignment(SwingConstants.LEFT);
		kangwonBtn.setForeground(Color.BLACK);
		kangwonBtn.setFont(new Font("NanumSquare", Font.PLAIN, 30));
		kangwonBtn.setBounds(267, 20, 60, 30);
		regionPanel.add(kangwonBtn);
		
		JButton deajeonBtn = new JButton("대전");
		deajeonBtn.setFocusable(false);
		deajeonBtn.addMouseListener(new MouseAdapter() {
			boolean isChecked = false;
			@Override
			public void mouseClicked(MouseEvent e) {
				if(!isChecked) {
					deajeonBtn.setFont(new Font("NanumSquare", Font.BOLD | Font.ITALIC, 30));
					isChecked = true;
				}
				else {
					deajeonBtn.setFont(new Font("NanumSquare", Font.PLAIN, 30));
					isChecked = false;
				}
			}
		});
		deajeonBtn.setBorder(null);
		deajeonBtn.setBackground(Color.WHITE);
		deajeonBtn.setHorizontalAlignment(SwingConstants.LEFT);
		deajeonBtn.setForeground(Color.BLACK);
		deajeonBtn.setFont(new Font("NanumSquare", Font.PLAIN, 30));
		deajeonBtn.setBounds(351, 20, 60, 30);
		regionPanel.add(deajeonBtn);
		
		JButton sejongBtn = new JButton("세종");
		sejongBtn.setFocusable(false);
		sejongBtn.addMouseListener(new MouseAdapter() {
			boolean isChecked = false;
			@Override
			public void mouseClicked(MouseEvent e) {
				if(!isChecked) {
					sejongBtn.setFont(new Font("NanumSquare", Font.BOLD | Font.ITALIC, 30));
					isChecked = true;
				}
				else {
					sejongBtn.setFont(new Font("NanumSquare", Font.PLAIN, 30));
					isChecked = false;
				}
			}
		});
		sejongBtn.setBorder(null);
		sejongBtn.setBackground(Color.WHITE);
		sejongBtn.setHorizontalAlignment(SwingConstants.LEFT);
		sejongBtn.setForeground(Color.BLACK);
		sejongBtn.setFont(new Font("NanumSquare", Font.PLAIN, 30));
		sejongBtn.setBounds(435, 20, 60, 30);
		regionPanel.add(sejongBtn);
		
		JButton chungnamBtn = new JButton("충남");
		chungnamBtn.setFocusable(false);
		chungnamBtn.addMouseListener(new MouseAdapter() {
			boolean isChecked = false;
			@Override
			public void mouseClicked(MouseEvent e) {
				if(!isChecked) {
					chungnamBtn.setFont(new Font("NanumSquare", Font.BOLD | Font.ITALIC, 30));
					isChecked = true;
				}
				else {
					chungnamBtn.setFont(new Font("NanumSquare", Font.PLAIN, 30));
					isChecked = false;
				}
			}
		});
		chungnamBtn.setBorder(null);
		chungnamBtn.setBackground(Color.WHITE);
		chungnamBtn.setHorizontalAlignment(SwingConstants.LEFT);
		chungnamBtn.setForeground(Color.BLACK);
		chungnamBtn.setFont(new Font("NanumSquare", Font.PLAIN, 30));
		chungnamBtn.setBounds(15, 70, 60, 30);
		regionPanel.add(chungnamBtn);
		
		JButton chungbukBtn = new JButton("충북");
		chungbukBtn.setFocusable(false);
		chungbukBtn.addMouseListener(new MouseAdapter() {
			boolean isChecked = false;
			@Override
			public void mouseClicked(MouseEvent e) {
				if(!isChecked) {
					chungbukBtn.setFont(new Font("NanumSquare", Font.BOLD | Font.ITALIC, 17));
					isChecked = true;
				}
				else {
					chungbukBtn.setFont(new Font("NanumSquare", Font.PLAIN, 17));
					isChecked = false;
				}
			}
		});
		chungbukBtn.setBorder(null);
		chungbukBtn.setBackground(Color.WHITE);
		chungbukBtn.setHorizontalAlignment(SwingConstants.LEFT);
		chungbukBtn.setForeground(Color.BLACK);
		chungbukBtn.setFont(new Font("NanumSquare", Font.PLAIN, 30));
		chungbukBtn.setBounds(99, 70, 60, 30);
		regionPanel.add(chungbukBtn);
		
		JButton busanBtn = new JButton("부산");
		busanBtn.setFocusable(false);
		busanBtn.addMouseListener(new MouseAdapter() {
			boolean isChecked = false;
			@Override
			public void mouseClicked(MouseEvent e) {
				if(!isChecked) {
					busanBtn.setFont(new Font("NanumSquare", Font.BOLD | Font.ITALIC, 30));
					isChecked = true;
				}
				else {
					busanBtn.setFont(new Font("NanumSquare", Font.PLAIN, 30));
					isChecked = false;
				}
			}
		});
		busanBtn.setBorder(null);
		busanBtn.setBackground(Color.WHITE);
		busanBtn.setHorizontalAlignment(SwingConstants.LEFT);
		busanBtn.setForeground(Color.BLACK);
		busanBtn.setFont(new Font("NanumSquare", Font.PLAIN, 30));
		busanBtn.setBounds(183, 70, 60, 30);
		regionPanel.add(busanBtn);
		
		JButton ulsanBtn = new JButton("울산");
		ulsanBtn.setFocusable(false);
		ulsanBtn.addMouseListener(new MouseAdapter() {
			boolean isChecked = false;
			@Override
			public void mouseClicked(MouseEvent e) {
				if(!isChecked) {
					ulsanBtn.setFont(new Font("NanumSquare", Font.BOLD | Font.ITALIC, 30));
					isChecked = true;
				}
				else {
					ulsanBtn.setFont(new Font("NanumSquare", Font.PLAIN, 30));
					isChecked = false;
				}
			}
		});
		ulsanBtn.setBorder(null);
		ulsanBtn.setBackground(Color.WHITE);
		ulsanBtn.setHorizontalAlignment(SwingConstants.LEFT);
		ulsanBtn.setForeground(Color.BLACK);
		ulsanBtn.setFont(new Font("NanumSquare", Font.PLAIN, 30));
		ulsanBtn.setBounds(267, 70, 60, 30);
		regionPanel.add(ulsanBtn);
		
		JButton gyeongnamBtn = new JButton("경남");
		gyeongnamBtn.setFocusable(false);
		gyeongnamBtn.addMouseListener(new MouseAdapter() {
			boolean isChecked = false;
			@Override
			public void mouseClicked(MouseEvent e) {
				if(!isChecked) {
					gyeongnamBtn.setFont(new Font("NanumSquare", Font.BOLD | Font.ITALIC, 30));
					isChecked = true;
				}
				else {
					gyeongnamBtn.setFont(new Font("NanumSquare", Font.PLAIN, 30));
					isChecked = false;
				}
			}
		});
		gyeongnamBtn.setBorder(null);
		gyeongnamBtn.setBackground(Color.WHITE);
		gyeongnamBtn.setHorizontalAlignment(SwingConstants.LEFT);
		gyeongnamBtn.setForeground(Color.BLACK);
		gyeongnamBtn.setFont(new Font("NanumSquare", Font.PLAIN, 30));
		gyeongnamBtn.setBounds(351, 70, 60, 30);
		regionPanel.add(gyeongnamBtn);
		
		JButton gyeongbukBtn = new JButton("경북");
		gyeongbukBtn.setFocusable(false);
		gyeongbukBtn.addMouseListener(new MouseAdapter() {
			boolean isChecked = false;
			@Override
			public void mouseClicked(MouseEvent e) {
				if(!isChecked) {
					gyeongbukBtn.setFont(new Font("NanumSquare", Font.BOLD | Font.ITALIC, 30));
					isChecked = true;
				}
				else {
					gyeongbukBtn.setFont(new Font("NanumSquare", Font.PLAIN, 30));
					isChecked = false;
				}
			}
		});
		gyeongbukBtn.setBorder(null);
		gyeongbukBtn.setBackground(Color.WHITE);
		gyeongbukBtn.setHorizontalAlignment(SwingConstants.LEFT);
		gyeongbukBtn.setForeground(Color.BLACK);
		gyeongbukBtn.setFont(new Font("NanumSquare", Font.PLAIN, 30));
		gyeongbukBtn.setBounds(435, 70, 60, 30);
		regionPanel.add(gyeongbukBtn);
		
		JButton daeguBtn = new JButton("대구");
		daeguBtn.setFocusable(false);
		daeguBtn.addMouseListener(new MouseAdapter() {
			boolean isChecked = false;
			@Override
			public void mouseClicked(MouseEvent e) {
				if(!isChecked) {
					daeguBtn.setFont(new Font("NanumSquare", Font.BOLD | Font.ITALIC, 30));
					isChecked = true;
				}
				else {
					daeguBtn.setFont(new Font("NanumSquare", Font.PLAIN, 30));
					isChecked = false;
				}
			}
		});
		daeguBtn.setBorder(null);
		daeguBtn.setBackground(Color.WHITE);
		daeguBtn.setHorizontalAlignment(SwingConstants.LEFT);
		daeguBtn.setForeground(Color.BLACK);
		daeguBtn.setFont(new Font("NanumSquare", Font.PLAIN, 30));
		daeguBtn.setBounds(15, 120, 60, 30);
		regionPanel.add(daeguBtn);
		
		JButton gwangjuBtn = new JButton("광주");
		gwangjuBtn.setFocusable(false);
		gwangjuBtn.addMouseListener(new MouseAdapter() {
			boolean isChecked = false;
			@Override
			public void mouseClicked(MouseEvent e) {
				if(!isChecked) {
					gwangjuBtn.setFont(new Font("NanumSquare", Font.BOLD | Font.ITALIC, 30));
					isChecked = true;
				}
				else {
					gwangjuBtn.setFont(new Font("NanumSquare", Font.PLAIN, 30));
					isChecked = false;
				}
			}
		});
		gwangjuBtn.setBorder(null);
		gwangjuBtn.setBackground(Color.WHITE);
		gwangjuBtn.setHorizontalAlignment(SwingConstants.LEFT);
		gwangjuBtn.setForeground(Color.BLACK);
		gwangjuBtn.setFont(new Font("NanumSquare", Font.PLAIN, 30));
		gwangjuBtn.setBounds(99, 120, 60, 30);
		regionPanel.add(gwangjuBtn);
		
		JButton jeonnamBtn = new JButton("전남");
		jeonnamBtn.setFocusable(false);
		jeonnamBtn.addMouseListener(new MouseAdapter() {
			boolean isChecked = false;
			@Override
			public void mouseClicked(MouseEvent e) {
				if(!isChecked) {
					jeonnamBtn.setFont(new Font("NanumSquare", Font.BOLD | Font.ITALIC, 30));
					isChecked = true;
				}
				else {
					jeonnamBtn.setFont(new Font("NanumSquare", Font.PLAIN, 30));
					isChecked = false;
				}
			}
		});
		jeonnamBtn.setBorder(null);
		jeonnamBtn.setBackground(Color.WHITE);
		jeonnamBtn.setHorizontalAlignment(SwingConstants.LEFT);
		jeonnamBtn.setForeground(Color.BLACK);
		jeonnamBtn.setFont(new Font("NanumSquare", Font.PLAIN, 30));
		jeonnamBtn.setBounds(183, 120, 60, 30);
		regionPanel.add(jeonnamBtn);
		
		JButton jeonbukBtn = new JButton("전북");
		jeonbukBtn.setFocusable(false);
		jeonbukBtn.addMouseListener(new MouseAdapter() {
			boolean isChecked = false;
			@Override
			public void mouseClicked(MouseEvent e) {
				if(!isChecked) {
					jeonbukBtn.setFont(new Font("NanumSquare", Font.BOLD | Font.ITALIC, 30));
					isChecked = true;
				}
				else {
					jeonbukBtn.setFont(new Font("NanumSquare", Font.PLAIN, 30));
					isChecked = false;
				}
			}
		});
		jeonbukBtn.setBorder(null);
		jeonbukBtn.setBackground(Color.WHITE);
		jeonbukBtn.setHorizontalAlignment(SwingConstants.LEFT);
		jeonbukBtn.setForeground(Color.BLACK);
		jeonbukBtn.setFont(new Font("NanumSquare", Font.PLAIN, 30));
		jeonbukBtn.setBounds(267, 120, 60, 30);
		regionPanel.add(jeonbukBtn);
		
		JButton jejuBtn = new JButton("제주");
		jejuBtn.setFocusable(false);
		jejuBtn.addMouseListener(new MouseAdapter() {
			boolean isChecked = false;
			@Override
			public void mouseClicked(MouseEvent e) {
				if(!isChecked) {
					jejuBtn.setFont(new Font("NanumSquare", Font.BOLD | Font.ITALIC, 30));
					isChecked = true;
				}
				else {
					jejuBtn.setFont(new Font("NanumSquare", Font.PLAIN, 30));
					isChecked = false;
				}
			}
		});
		jejuBtn.setBorder(null);
		jejuBtn.setBackground(Color.WHITE);
		jejuBtn.setHorizontalAlignment(SwingConstants.LEFT);
		jejuBtn.setForeground(Color.BLACK);
		jejuBtn.setFont(new Font("NanumSquare", Font.PLAIN, 30));
		jejuBtn.setBounds(351, 120, 60, 30);
		regionPanel.add(jejuBtn);
		
		JButton allBtn = new JButton("전국");
		allBtn.setFocusable(false);
		allBtn.addMouseListener(new MouseAdapter() {
			boolean isChecked = false;
			@Override
			public void mouseClicked(MouseEvent e) {
				if(!isChecked) {
					allBtn.setFont(new Font("NanumSquare", Font.BOLD | Font.ITALIC, 30));
					isChecked = true;
				}
				else {
					allBtn.setFont(new Font("NanumSquare", Font.PLAIN, 30));
					isChecked = false;
				}
			}
		});
		allBtn.setBorder(null);
		allBtn.setBackground(Color.WHITE);
		allBtn.setHorizontalAlignment(SwingConstants.LEFT);
		allBtn.setForeground(Color.BLACK);
		allBtn.setFont(new Font("NanumSquare", Font.PLAIN, 30));
		allBtn.setBounds(435, 120, 60, 30);
		regionPanel.add(allBtn);
		
		JTextField mainText1 = new JTextField();
		mainText1.setBorder(null);
		mainText1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				recruitmentInformationUI recruitmentInfo1 = new recruitmentInformationUI();
				recruitmentInfo1.setVisible(true);
				setVisible(false);
			}
		});
		mainText1.setText("내용");
		mainText1.setBounds(142, 338, 252, 26);
		contentPanel.add(mainText1);
		mainText1.setColumns(10);
		
		JTextField mainText2 = new JTextField();
		mainText2.setBorder(null);
		mainText2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				recruitmentInformationUI recruitmentInfo1 = new recruitmentInformationUI();
				recruitmentInfo1.setVisible(true);
				setVisible(false);
			}
		});
		mainText2.setText("내용");
		mainText2.setColumns(10);
		mainText2.setBounds(142, 440, 252, 26);
		contentPanel.add(mainText2);
		
		JTextField mainText3 = new JTextField();
		mainText3.setBorder(null);
		mainText3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				recruitmentInformationUI recruitmentInfo1 = new recruitmentInformationUI();
				recruitmentInfo1.setVisible(true);
				setVisible(false);
			}
		});
		mainText3.setText("내용");
		mainText3.setColumns(10);
		mainText3.setBounds(142, 538, 252, 26);
		contentPanel.add(mainText3);
		
		JTextField mainText4 = new JTextField();
		mainText4.setBorder(null);
		mainText4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				recruitmentInformationUI recruitmentInfo1 = new recruitmentInformationUI();
				recruitmentInfo1.setVisible(true);
				setVisible(false);
			}
		});
		mainText4.setText("내용");
		mainText4.setColumns(10);
		mainText4.setBounds(142, 638, 252, 26);
		contentPanel.add(mainText4);
		
		ImageIcon originalIcon = new ImageIcon("C:\\Users\\SAMSUNG\\eclipse-workspace\\Workable\\src\\image\\filter.png");
		Image filterImg = originalIcon.getImage();
		filterImg = filterImg.getScaledInstance(130, 50, Image.SCALE_DEFAULT);
		ImageIcon filterIcon = new ImageIcon(filterImg);
		JLabel advancedSearchBtn = new JLabel(filterIcon);
		advancedSearchBtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				advancedSearchUI advancedSearch = new advancedSearchUI();
				advancedSearch.setVisible(true);
				setVisible(false);
			}
		});
		
		advancedSearchBtn.setBounds(383, 241, 152, 51);
		contentPanel.add(advancedSearchBtn);
		
		ImageIcon icon = new ImageIcon("C:\\Users\\SAMSUNG\\eclipse-workspace\\Workable\\src\\image\\prevBtn.png");
		Image previm = icon.getImage();
		Image previm2 = previm.getScaledInstance(50, 50, Image.SCALE_DEFAULT);
		ImageIcon icon2 = new ImageIcon(previm2);
		JButton prevBtn = new JButton(icon2);
		prevBtn.setForeground(Color.ORANGE);
		prevBtn.setBorder(null);
		prevBtn.setBackground(Color.WHITE);
		prevBtn.setBounds(200, 722, 50, 50);
		contentPanel.add(prevBtn);
		
		ImageIcon icon3 = new ImageIcon("C:\\Users\\SAMSUNG\\eclipse-workspace\\Workable\\src\\image\\nextBtn.png");
		Image nextim3 = icon3.getImage();
		Image nextim4 = nextim3.getScaledInstance(50, 50, Image.SCALE_DEFAULT);
		ImageIcon icon4 = new ImageIcon(nextim4);
		JButton nextBtn = new JButton(icon4);
		nextBtn.setForeground(Color.ORANGE);
		nextBtn.setBorder(null);
		nextBtn.setBackground(Color.WHITE);		
		nextBtn.setBounds(310, 722, 50, 50);
		contentPanel.add(nextBtn);
		
		JPanel topPanel = new JPanel();
		topPanel.setBorder(new LineBorder(new Color(0, 0, 0)));
		topPanel.setName("Workable");
		topPanel.setFont(new Font("NanumSquare", Font.PLAIN, 15));
		topPanel.setToolTipText("Workable");
		topPanel.setBackground(new Color(255, 165, 0));
		topPanel.setBounds(0, 0, 544, 80);
		topPanel.setBorder(new LineBorder(new Color(255, 165, 0)));
		mainPanel.add(topPanel);
		topPanel.setLayout(null);
		
		JLabel topLabel = new JLabel("지역별");
		topLabel.setBounds(1, 20, 544, 40);
		topLabel.setAlignmentX(0.5f);
		topLabel.setHorizontalAlignment(SwingConstants.CENTER);
		topLabel.setFont(new Font("NanumSquare", Font.PLAIN, 40));
		topPanel.add(topLabel);
		
		ImageIcon icon5 = new ImageIcon("C:\\Users\\SAMSUNG\\eclipse-workspace\\Workable\\src\\image\\backBtn.png");
		Image backim = icon5.getImage();
		Image backim2 = backim.getScaledInstance(30, 30, Image.SCALE_DEFAULT);
		ImageIcon icon6 = new ImageIcon(backim2);
		JButton backBtn = new JButton(icon6);
		backBtn.setFocusable(false);
		backBtn.setBorder(null);
		backBtn.setBackground(new Color(255, 165, 0));
		backBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				javaraUI javara = new javaraUI();
				javara.setVisible(true);
				setVisible(false);
			}
		});
		backBtn.setBounds(12, 16, 48, 48);
		topPanel.add(backBtn);
	}
}
